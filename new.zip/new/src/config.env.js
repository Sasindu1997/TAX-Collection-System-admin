// export const BASE_URL = "http://127.0.0.1:8000";
// export const NODE_ENV = "development";

export const BASE_URL = "http://143.42.66.199:8000";
export const NODE_ENV = "development";